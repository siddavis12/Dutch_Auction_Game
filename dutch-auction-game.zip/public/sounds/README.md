# Sounds Directory

Place your MP3 audio files here:
- `auction-start.mp3` - Played when an auction starts
- `auction-won.mp3` - Played when someone wins an auction

Audio requirements:
- Format: MP3
- Recommended: Keep file size under 1MB for quick loading
- Suggested duration: 2-5 seconds for sound effects
- Volume levels: auction-start (0.7), auction-won (0.8)