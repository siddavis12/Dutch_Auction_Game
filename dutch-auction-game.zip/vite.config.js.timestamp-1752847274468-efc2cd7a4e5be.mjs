// vite.config.js
import { defineConfig } from "file:///D:/Dropbox/ETC/Vive/dutch-auction-game/node_modules/vite/dist/node/index.js";
import react from "file:///D:/Dropbox/ETC/Vive/dutch-auction-game/node_modules/@vitejs/plugin-react/dist/index.mjs";
var vite_config_default = defineConfig({
  plugins: [react()],
  server: {
    port: 3e3,
    proxy: {
      "/socket.io": {
        target: "http://localhost:3500",
        ws: true
      }
    }
  },
  build: {
    rollupOptions: {
      output: {
        // 파일명에 해시 추가로 캐시 무효화
        entryFileNames: "assets/[name]-[hash].js",
        chunkFileNames: "assets/[name]-[hash].js",
        assetFileNames: "assets/[name]-[hash].[ext]",
        // 큰 라이브러리들을 별도 청크로 분리
        manualChunks: {
          "react-vendor": ["react", "react-dom"],
          "animation-vendor": ["framer-motion"],
          "styled-vendor": ["styled-components"],
          "socket-vendor": ["socket.io-client"]
        }
      }
    },
    // 청크 크기 경고 임계값 조정 (선택사항)
    chunkSizeWarningLimit: 600
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCJEOlxcXFxEcm9wYm94XFxcXEVUQ1xcXFxWaXZlXFxcXGR1dGNoLWF1Y3Rpb24tZ2FtZVwiO2NvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9maWxlbmFtZSA9IFwiRDpcXFxcRHJvcGJveFxcXFxFVENcXFxcVml2ZVxcXFxkdXRjaC1hdWN0aW9uLWdhbWVcXFxcdml0ZS5jb25maWcuanNcIjtjb25zdCBfX3ZpdGVfaW5qZWN0ZWRfb3JpZ2luYWxfaW1wb3J0X21ldGFfdXJsID0gXCJmaWxlOi8vL0Q6L0Ryb3Bib3gvRVRDL1ZpdmUvZHV0Y2gtYXVjdGlvbi1nYW1lL3ZpdGUuY29uZmlnLmpzXCI7aW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZSdcbmltcG9ydCByZWFjdCBmcm9tICdAdml0ZWpzL3BsdWdpbi1yZWFjdCdcblxuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29uZmlnKHtcbiAgcGx1Z2luczogW3JlYWN0KCldLFxuICBzZXJ2ZXI6IHtcbiAgICBwb3J0OiAzMDAwLFxuICAgIHByb3h5OiB7XG4gICAgICAnL3NvY2tldC5pbyc6IHtcbiAgICAgICAgdGFyZ2V0OiAnaHR0cDovL2xvY2FsaG9zdDozNTAwJyxcbiAgICAgICAgd3M6IHRydWVcbiAgICAgIH1cbiAgICB9XG4gIH0sXG4gIGJ1aWxkOiB7XG4gICAgcm9sbHVwT3B0aW9uczoge1xuICAgICAgb3V0cHV0OiB7XG4gICAgICAgIC8vIFx1RDMwQ1x1Qzc3Q1x1QkE4NVx1QzVEMCBcdUQ1NzRcdUMyREMgXHVDRDk0XHVBQzAwXHVCODVDIFx1Q0U5MFx1QzJEQyBcdUJCMzRcdUQ2QThcdUQ2NTRcbiAgICAgICAgZW50cnlGaWxlTmFtZXM6ICdhc3NldHMvW25hbWVdLVtoYXNoXS5qcycsXG4gICAgICAgIGNodW5rRmlsZU5hbWVzOiAnYXNzZXRzL1tuYW1lXS1baGFzaF0uanMnLFxuICAgICAgICBhc3NldEZpbGVOYW1lczogJ2Fzc2V0cy9bbmFtZV0tW2hhc2hdLltleHRdJyxcbiAgICAgICAgLy8gXHVEMDcwIFx1Qjc3Q1x1Qzc3NFx1QkUwQ1x1QjdFQ1x1QjlBQ1x1QjRFNFx1Qzc0NCBcdUJDQzRcdUIzQzQgXHVDQ0FEXHVEMDZDXHVCODVDIFx1QkQ4NFx1QjlBQ1xuICAgICAgICBtYW51YWxDaHVua3M6IHtcbiAgICAgICAgICAncmVhY3QtdmVuZG9yJzogWydyZWFjdCcsICdyZWFjdC1kb20nXSxcbiAgICAgICAgICAnYW5pbWF0aW9uLXZlbmRvcic6IFsnZnJhbWVyLW1vdGlvbiddLFxuICAgICAgICAgICdzdHlsZWQtdmVuZG9yJzogWydzdHlsZWQtY29tcG9uZW50cyddLFxuICAgICAgICAgICdzb2NrZXQtdmVuZG9yJzogWydzb2NrZXQuaW8tY2xpZW50J11cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgLy8gXHVDQ0FEXHVEMDZDIFx1RDA2Q1x1QUUzMCBcdUFDQkRcdUFDRTAgXHVDNzg0XHVBQ0M0XHVBQzEyIFx1Qzg3MFx1QzgxNSAoXHVDMTIwXHVEMEREXHVDMEFDXHVENTZEKVxuICAgIGNodW5rU2l6ZVdhcm5pbmdMaW1pdDogNjAwXG4gIH1cbn0pIl0sCiAgIm1hcHBpbmdzIjogIjtBQUE4UyxTQUFTLG9CQUFvQjtBQUMzVSxPQUFPLFdBQVc7QUFFbEIsSUFBTyxzQkFBUSxhQUFhO0FBQUEsRUFDMUIsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUFBLEVBQ2pCLFFBQVE7QUFBQSxJQUNOLE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxNQUNMLGNBQWM7QUFBQSxRQUNaLFFBQVE7QUFBQSxRQUNSLElBQUk7QUFBQSxNQUNOO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE9BQU87QUFBQSxJQUNMLGVBQWU7QUFBQSxNQUNiLFFBQVE7QUFBQTtBQUFBLFFBRU4sZ0JBQWdCO0FBQUEsUUFDaEIsZ0JBQWdCO0FBQUEsUUFDaEIsZ0JBQWdCO0FBQUE7QUFBQSxRQUVoQixjQUFjO0FBQUEsVUFDWixnQkFBZ0IsQ0FBQyxTQUFTLFdBQVc7QUFBQSxVQUNyQyxvQkFBb0IsQ0FBQyxlQUFlO0FBQUEsVUFDcEMsaUJBQWlCLENBQUMsbUJBQW1CO0FBQUEsVUFDckMsaUJBQWlCLENBQUMsa0JBQWtCO0FBQUEsUUFDdEM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBO0FBQUEsSUFFQSx1QkFBdUI7QUFBQSxFQUN6QjtBQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
